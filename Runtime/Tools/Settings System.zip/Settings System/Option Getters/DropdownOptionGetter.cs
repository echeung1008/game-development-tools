using System.Collections.Generic;
using UnityEngine;

namespace BlueMuffinGames.Tools.SettingsSystem
{
    public abstract class DropdownOptionGetter : TypedSettingOptionGetter<DropdownOption>
    {
        
    }
}
